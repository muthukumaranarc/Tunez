import Song from './Song.jsx';
import arrow from '../assets/arrow.png';
import './Home.css';
import { useRef, useState, useEffect } from 'react';

function Home() {
    
    const [songs, setSongs] = useState([]);

    useEffect(() => {
    fetch('http://localhost:7000/song/get/all/20')
      .then(response => response.json())
      .then(data => {
        setSongs(data);
      })
      .catch(error => {
        console.error('Error fetching data:', error);
      });
    }, []);

    const scrollRef = useRef(null);

    let [disable, setDisable] = useState(false);

    const scrollLeft = () => {
        setDisable(true);
        scrollRef.current.scrollBy({left: -460, behavior: 'smooth'});
        setDisable(false);
    };

    const scrollRight = () => {
        setDisable(true);
        const container = scrollRef.current;
        const maxScroll = container.scrollWidth - container.clientWidth;
        const newScroll = container.scrollLeft + 460;

        if (newScroll >= maxScroll) {
            container.scrollTo({ left: 0, behavior: 'smooth' });
        } else {
            container.scrollBy({ left: 460, behavior: 'smooth' });
        }
        setTimeout(() => {
            setDisable(false);
        }, 500);
    };


    return (
        <>
        <div className='deColl'>
            <button className='dailyBeat'>
                <p>Daily Beat</p>
                <div style={{
                    backgroundImage: "url(http://localhost:7000/song/get/image/any)",
                    backgroundSize: 'cover',
                    backgroundPosition: 'center'
                }}></div>
            </button>
            <button className='ourNew'>
                <p>Try our new Collection</p>
                <div style={{
                    backgroundImage: "url(http://localhost:7000/song/get/image/any/any)",
                    backgroundSize: 'cover',
                    backgroundPosition: 'center'
                }}></div>
            </button>
        </div><br/><br/>


        <div className='quickPick'>
        <div className='controlS'>
            <button className='playAll'>Play All</button>
            <button className='leftS' onClick={scrollLeft} disabled={disable}><img src={arrow}/></button>
            <button className='rightS' onClick={scrollRight} disabled={disable}><img src={arrow}/></button>
        </div>
        <h2>Quick picks</h2>
        <div className='songs' ref={scrollRef}>
        {
            songs.map(( item,  ) => (
                <Song key={item.id} data={item}/>
            ))
        }
        </div>
        </div><br/><br/>
        </>
    )
}

export default Home;