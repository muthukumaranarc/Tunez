import Category from './Category';
import './Content.css'
import Home from './Home';

function Content() {
    return (
        <div className='Content'>
            <Category />
            <Home />
        </div>
    )
}

export default Content;