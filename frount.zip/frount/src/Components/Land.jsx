import Content from './Content';
import Head from './Head';
import Menu from './Menu';

import './Land.css';

import { useState } from 'react';

function Land() {

    let [menuState , setMenuState ] = useState(true);

    return (
        <>
        <Head menuState = {menuState} setMenuState = {setMenuState}/>
        <div style={{height:"49px"}}></div>
        {
            (menuState) ? <Menu/> : <div></div> 
        }
        <div style={{display:'flex'}}>
            <div style={{width: menuState ? '260px' : '0px'}}></div> 
            <Content menuState = {menuState}/>
        </div>
        </>
    )
}

export default Land;