// import { useState } from 'react';
import './PlaySong.css';

function PlaySong({song}) {

    return (
        <div className='PlaySong'>
            <div style={{
                backgroundImage: `url(src/assets/DailyMusic.jpeg)`,
                backgroundSize: 'cover',
                backgroundPosition: 'center'
            }}></div>
            <h2>{song.name}</h2>
            <p>{song.artist}</p>
            <div className='playControl'>
                <button className='Prev'></button>
                <button className='play'></button>
                <button className='next'></button>
            </div>
        </div>
    )
}

export default PlaySong;